package lk.express.reporting;

public class ReportData {

	private String logoFile;

	public String getLogoFile() {
		return logoFile;
	}

	public void setLogoFile(String logoFile) {
		this.logoFile = logoFile;
	}
}

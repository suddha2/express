package lk.express.reporting;

public interface IReport {

	ReportInfo generateReport() throws Exception;

}
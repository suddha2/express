package lk.express.search.api.v2;

public abstract class APICriteria {

	/**
	 * @exclude
	 */
	public String validate() {
		return null;
	}
}

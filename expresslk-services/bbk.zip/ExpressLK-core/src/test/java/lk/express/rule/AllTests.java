package lk.express.rule;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ CombinerTest.class, QualifierTest.class })
public class AllTests {

}

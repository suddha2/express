package lk.express.api.v2;

public class APIPayment extends APIPaymentRefund {

	/**
	 * @exclude
	 */
	public APIPayment() {

	}

	/**
	 * @exclude
	 */
	public APIPayment(lk.express.bean.Payment e) {
		super(e);
	}
}

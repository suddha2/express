package lk.express.notification.sms;

import lk.express.notification.INotifier;
import lk.express.notification.NotificationCriteria;

/**
 * @author dilantha
 *
 */
public class SMSNotifier implements INotifier {

	@Override
	public void send(NotificationCriteria criteria) {
		// TODO Auto-generated method stub

	}

}

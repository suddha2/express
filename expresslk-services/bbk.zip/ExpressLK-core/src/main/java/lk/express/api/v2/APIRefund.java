package lk.express.api.v2;

public class APIRefund extends APIPaymentRefund {

	/**
	 * @exclude
	 */
	public APIRefund() {

	}

	/**
	 * @exclude
	 */
	public APIRefund(lk.express.bean.Refund e) {
		super(e);
	}
}

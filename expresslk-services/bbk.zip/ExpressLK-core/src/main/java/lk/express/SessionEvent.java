package lk.express;

public interface SessionEvent {

	public Session getSession();
}

package lk.express.reservation.listener;

/**
 * @author dilantha
 *
 */
public interface BookingChangeListener {

	void onChange(BookingChangeEvent event);
}

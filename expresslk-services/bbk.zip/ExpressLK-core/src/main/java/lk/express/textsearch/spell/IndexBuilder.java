package lk.express.textsearch.spell;

public interface IndexBuilder {

	Index build();
}

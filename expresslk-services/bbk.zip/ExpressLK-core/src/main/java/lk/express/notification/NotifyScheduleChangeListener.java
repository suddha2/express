package lk.express.notification;

import lk.express.schedule.ScheduleChangeEvent;
import lk.express.schedule.ScheduleChangeListener;

/**
 * @author dilantha
 * 
 */
public class NotifyScheduleChangeListener implements ScheduleChangeListener {

	@Override
	public void onChange(ScheduleChangeEvent e) {
		// TODO Auto-generated method stub

	}

}

package lk.express.bean;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement
@XmlType(name = "AdvisoryNote", namespace = "http://bean.express.lk")
public class AdvisoryNote {

}

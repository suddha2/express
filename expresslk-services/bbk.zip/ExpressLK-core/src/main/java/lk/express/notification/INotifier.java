package lk.express.notification;

/**
 * @author dilantha
 * 
 */
public interface INotifier {

	public void send(NotificationCriteria criteria);

}

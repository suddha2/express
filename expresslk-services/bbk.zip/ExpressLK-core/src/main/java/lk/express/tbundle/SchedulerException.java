package lk.express.tbundle;

public class SchedulerException extends Exception {

	private static final long serialVersionUID = 1L;

	public SchedulerException(Throwable t) {
		super(t);
	}
}

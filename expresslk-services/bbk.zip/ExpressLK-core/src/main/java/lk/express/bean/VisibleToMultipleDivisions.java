package lk.express.bean;

public interface VisibleToMultipleDivisions {

}

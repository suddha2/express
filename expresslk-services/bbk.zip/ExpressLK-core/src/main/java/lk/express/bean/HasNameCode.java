package lk.express.bean;

public interface HasNameCode {

	public String getName();

	public String getCode();
}

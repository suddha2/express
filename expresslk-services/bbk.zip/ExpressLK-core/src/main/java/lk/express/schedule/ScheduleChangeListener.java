package lk.express.schedule;

public interface ScheduleChangeListener {

	void onChange(ScheduleChangeEvent e);
}

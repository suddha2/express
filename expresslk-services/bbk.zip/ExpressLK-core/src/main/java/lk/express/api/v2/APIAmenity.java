package lk.express.api.v2;

public class APIAmenity extends APINameCodeEntity {

	/**
	 * @exclude
	 */
	public APIAmenity() {

	}

	/**
	 * @exclude
	 */
	public APIAmenity(lk.express.bean.Amenity e) {
		super(e);
	}
}

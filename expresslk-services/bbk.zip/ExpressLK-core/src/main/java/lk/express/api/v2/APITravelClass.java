package lk.express.api.v2;

public class APITravelClass extends APINameCodeEntity {

	/**
	 * @exclude
	 */
	public APITravelClass() {

	}

	/**
	 * @exclude
	 */
	public APITravelClass(lk.express.bean.TravelClass e) {
		super(e);
	}
}

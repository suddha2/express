package lk.express.bean;

import java.util.Date;

public interface HasValidPeriod {

	Date getStartTime();

	Date getEndTime();
}
